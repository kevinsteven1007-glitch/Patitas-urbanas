import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import {
  Guarderia,
  GuarderiaDocument,
  GuarderiaComentario,
} from './schemas/guarderia.schema.js';

@Injectable()
export class GuarderiasService {
  constructor(
    @InjectModel(Guarderia.name)
    private guarderiaModel: Model<GuarderiaDocument>,
  ) {}

  async create(data: Partial<Guarderia>): Promise<Guarderia> {
    const created = new this.guarderiaModel(data);
    return created.save();
  }

  async findAll(): Promise<Guarderia[]> {
    return this.guarderiaModel.find().sort({ createdAt: -1 }).exec();
  }

  async findOne(id: string): Promise<Guarderia | null> {
    return this.guarderiaModel.findById(id).exec();
  }

  async findByAutor(autorId: string): Promise<Guarderia[]> {
    return this.guarderiaModel
      .find({ autorId })
      .sort({ createdAt: -1 })
      .exec();
  }

  async update(
    id: string,
    data: Partial<Guarderia>,
  ): Promise<Guarderia | null> {
    return this.guarderiaModel
      .findByIdAndUpdate(id, data, { new: true })
      .exec();
  }

  async remove(id: string): Promise<Guarderia | null> {
    return this.guarderiaModel.findByIdAndDelete(id).exec();
  }

  async toggleLike(id: string, userId: string): Promise<Guarderia | null> {
    const doc = await this.guarderiaModel.findById(id).exec();
    if (!doc) return null;

    const likedBy: string[] = (doc as any).likedBy || [];
    const alreadyLiked = likedBy.includes(userId);

    if (alreadyLiked) {
      return this.guarderiaModel
        .findByIdAndUpdate(
          id,
          { $pull: { likedBy: userId }, $inc: { likeCount: -1 } },
          { new: true },
        )
        .exec();
    } else {
      return this.guarderiaModel
        .findByIdAndUpdate(
          id,
          { $addToSet: { likedBy: userId }, $inc: { likeCount: 1 } },
          { new: true },
        )
        .exec();
    }
  }

  async addComentario(
    id: string,
    comentario: Partial<GuarderiaComentario>,
  ): Promise<Guarderia | null> {
    return this.guarderiaModel
      .findByIdAndUpdate(
        id,
        {
          $push: { comentariosReview: comentario },
          $inc: { commentCount: 1 },
        },
        { new: true },
      )
      .exec();
  }

  async getComentarios(id: string): Promise<GuarderiaComentario[]> {
    const doc = await this.guarderiaModel.findById(id).exec();
    return doc ? (doc as any).comentariosReview || [] : [];
  }
}
