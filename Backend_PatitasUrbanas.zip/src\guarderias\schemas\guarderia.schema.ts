import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type GuarderiaComentarioDocument = GuarderiaComentario & Document;

@Schema({ _id: true })
export class GuarderiaComentario {
  @Prop({ required: true })
  autorId: string;

  @Prop()
  autorAlias: string;

  @Prop({ min: 1, max: 5 })
  calificacion: number;

  @Prop()
  titulo: string;

  @Prop({ required: true })
  texto: string;

  @Prop({ default: () => new Date() })
  fechaCreacion: Date;
}

export const GuarderiaComentarioSchema =
  SchemaFactory.createForClass(GuarderiaComentario);

export type GuarderiaDocument = Guarderia & Document;

@Schema({ collection: 'guarderias', timestamps: true })
export class Guarderia {
  @Prop({ required: true })
  nombre: string;

  @Prop()
  ubicacion: string;

  @Prop()
  direccion: string;

  @Prop()
  servicio: string;

  @Prop()
  calificacion: string;

  @Prop()
  tratoMascotas: string;

  @Prop()
  comentarios: string;

  @Prop()
  autorId: string;

  @Prop({ default: 0 })
  likeCount: number;

  @Prop({ type: [String], default: [] })
  likedBy: string[];

  @Prop({ default: 0 })
  commentCount: number;

  @Prop({ type: [GuarderiaComentarioSchema], default: [] })
  comentariosReview: GuarderiaComentario[];
}

export const GuarderiaSchema = SchemaFactory.createForClass(Guarderia);
